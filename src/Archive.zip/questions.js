'use strict';
module.exports = {
	'QUESTIONS_EN_US' : [
		{
			'When was the first World Cup?' : [
				'1940',
				'1900',
				'1944',
				'1840',
				'1920'
			]
		},
		{
			' Wich is the selection that has participated the most in the World Cups?' : [
				'Brazil',
				'Alemania',
				'Itialia',
				'Argentina',
				'Nicaragua'
			]
		},
		{
			'Which one of the followings never have been on a World Cup?' : [
				'Nicaragua',
				'El Salvador',
				'Honduras',
				'Republica Checa'
			]
		},
		{
			'Who is the World Cup top scorer?' : [
				'Miroslav Klose',
				'Luiz Ronaldo',
				'Pelé',
				'Gabriel Batistuta'
			]
		},
		{
			'Which team had more players with golden balls?' : [
				'AC Milán',
				'Real Madrid',
				'Barcelona',
				'Manchester United'
			]
		},
		{
			'Which selections had won the most world cup?' : [
				'Brazil',
				'Alemania',
				'Italia',
				'Argentina',
				'Uruguay'
			]
		},
		{
			'Who wins the golden ball in 2004?' : [
				'Andriy Shevchenko',
				'Luis Figo',
				'Michael Owen',
				'Ronaldinho Gaucho'
			]
		},
		{
			'Who wins the golden ball in 2007?' : [
				'Ricardo Kaká',
				'Andriy Shevchenko',
				'Lionel Messi',
				'Cristiano Ronaldo'
			]
		},
		{
			'Who was named as the best player in the world in 2002?' : [
				'Luis Ronaldo',
				'Michael Owen',
				'Rivaldo',
				'Zinedine Zidane'
			]
		},
		{
			'Who is considered the best defender ever in all times?' : [
				'Paolo Maldini',
				'Fabio Cannavaro',
				'Stephan Effemberg',
				'Roberto Carlos'
			]
		}
	],

	'QUESTIONS_ES' : [
		{
			'Cuando fue el primer mundial?' : [
				'1940',
				'1900',
				'1944',
				'1840',
				'1920'
			]
		},
		{
			'Cual es la seleccion que ha participado mas en las copas del mundo?' : [
				'Brazil',
				'Alemania',
				'Itialia',
				'Argentina',
				'Nicaragua'
			]
		},
		{
			'Cual de las siguientes selecciones nunca ha ido a un mundial?' : [
				'Nicaragua',
				'El Salvador',
				'Honduras',
				'Republica Checa'
			]
		},
		{
			'Quien es el goleador de los mundiales?' : [
				'Miroslav Klose',
				'Luiz Ronaldo',
				'Pelé',
				'Gabriel Batistuta'
			]
		},
		{
			'Que equipo tiene mas jugadores con balones de oro?' : [
				'AC Milán',
				'Real Madrid',
				'Barcelona',
				'Manchester United'
			]
		},
		{
			'Que seleccion es la que mas mundiales ha ganado?' : [
				'Brazil',
				'Alemania',
				'Italia',
				'Argentina',
				'Uruguay'
			]
		},
		{
			'Quien ganó el balón de Oro en el 2004?' : [
				'Andriy Shevchenko',
				'Luis Figo',
				'Michael Owen',
				'Ronaldinho Gaucho'
			]
		},
		{
			'Quien ganó el balón de oro en el 2007?' : [
				'Ricardo Kaká',
				'Andriy Shevchenko',
				'Lionel Messi',
				'Cristiano Ronaldo'
			]
		},
		{
			'Quien fue nombrado como mejor jugador del mundo en el 2002?' : [
				'Luis Ronaldo',
				'Michael Owen',
				'Rivaldo',
				'Zinedine Zidane'
			]
		},
		{
			'Quien es considerado el mejor defensor de todos los tiempos?' : [
				'Paolo Maldini',
				'Fabio Cannavaro',
				'Stephan Effemberg',
				'Roberto Carlos'
			]
		}

	]
		
};